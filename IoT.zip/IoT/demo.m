x = 5;
y = fact(2)

function f = fact(n)
    f = prod(1:n);
end