syms x
eqn = 2*x-2 == 0;
solx = solve(eqn, x)